class LegResult
  include Mongoid::Document
  field :secs, type: Float

  embedded_in :entrant
  embedded_in :parent, polymorphic: true
  embeds_one :event, as: :parent, class_name: 'Event'

  validates_presence_of :event

  def calc_ave
  end

  after_initialize do |doc|
  	calc_ave
  end

  def secs=value
  	self[:secs] = value
  	calc_ave
  end
end
