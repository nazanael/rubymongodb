require 'test_helper'

class SwimResultTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
