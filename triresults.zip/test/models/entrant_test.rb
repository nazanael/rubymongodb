require 'test_helper'

class EntrantTest < ActiveSupport::TestCase
  # test "the truth" do
  #   assert true
  # end
end
